<?php
App::uses('AppModel', 'Model');
/**
 * SaleRep Model
 *
 * @property SaleRep $SaleRep
 * @property  $
 */
class HrDuringLeaveRecord extends AppModel {

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
		
		
	);



}
