<!-- #section:basics/content.breadcrumbs -->
<div class="breadcrumbs" id="breadcrumbs">
	<script type="text/javascript">
	try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
	</script>

	<ul class="breadcrumb">
		<li>
			<i class="ace-icon fa fa-home home-icon"></i>
			<a href="#">Home</a>
		</li>
			<li class="active">Dashboard</li>
	</ul><!-- /.breadcrumb -->

</div>
<style>
.small-box {
    border-radius: 2px;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
    display: block;
    margin-bottom: 20px;
    position: relative;
}
.small-box .icon {
    color: rgba(0, 0, 0, 0.15);
    font-size: 90px;
    position: absolute;
    right: 10px;
    top: -10px;
    transition: all 0.3s linear 0s;
    z-index: 0;
}
.small-box > .small-box-footer {
    background: rgba(0, 0, 0, 0.1) none repeat scroll 0 0;
    color: rgba(255, 255, 255, 0.8);
    display: block;
    padding: 3px 0;
    position: relative;
    text-align: center;
    text-decoration: none;
    z-index: 10;
}
</style>
<div class="page-content">
<div class="page-header">
	<h1>
		Dashboard
		<small>
			<i class="ace-icon fa fa-angle-double-right"></i>
			overview &amp; stats
		</small>
	</h1>
</div><!-- /.page-header -->
<div class="row">
	<div class="col-xs-12">
	<div class="alert alert-block alert-success">
		<button type="button" class="close" data-dismiss="alert">
		<i class="ace-icon fa fa-times"></i>
		</button>
		<i class="ace-icon fa fa-check green"></i>

		Welcome to
		<strong class="green">
		<?php echo SITENAME ; ?> Admin		
		</strong>
		
	</div>
	 <div class="row">
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow" style="background-color: #F79263 !important;color:#fff;">
                <div class="inner" style="padding:10px;">
                  <h3>#<?php echo $totalcate; ?></h3>
                  <p>Category</p>
                </div>
                <div class="icon">
                  <i class="fa fa-user"></i>
                </div>
                <a href="<?php echo rtrim(SITEURL, '/') . '/admin/categories'; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              
              <div class="small-box bg-red" style="background-color: #CC5D5E !important;color:#fff;">
                <div class="inner" style="padding:10px;">
                  <h3>#<?php echo $totalpro; ?></h3>
                  <p>Products</p>
                </div>
                <div class="icon">
                  <i class="fa fa-briefcase "></i>
                </div>
                <a href="<?php echo SITEURL.'admin/products' ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
			<div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua" style="background-color: #AEC95B !important;color:#fff;">
                <div class="inner" style="padding:10px;">
                  <h3>#<?php echo $totalStaff; ?></h3>
                  <p>Total Staff Member</p>
                </div>
                <div class="icon">
                  <i class="fa fa-user"></i>
                </div>
                <a href="<?php echo SITEURL.'admin/users/staff' ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
             
              <div class="small-box bg-green" style="background-color: #8BC1E4 !important;color:#fff;">
                <div class="inner" style="padding:10px;">
                  <h3>#<?php echo $totalCustomer; ?></h3>
                  <p>Total Customer</p>
                </div>
                <div class="icon">
                  <i class="fa fa-user"></i>
                </div>
                <a href="<?php echo SITEURL.'admin/users/customer' ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div>
          </div><!-- /.row -->
		  
		  
		  <div class="page-header">
			<h1>EOI Mailer Stats</h1>
		</div>
		  <div class="row">
			<div class="col-xs-6">
				<div class="table-responsive">
				<table class="table table-striped table-bordered table-hover" id="example" >
					<thead>
						<tr>
							<th>id</th>
							<th>Name</th>
							<th>Total Sent</th>
						</tr>	
					</thead>
					<tbody>
						<?php 
						$i=1;
						foreach ($UserPermission as $UserPermissions): ?>
						<tr>
						<td><?php echo $i; ?>&nbsp;</td>
						<td><?php
							$napp = $UserPermissions['NappUser'] ?? [];
							$name = $napp['name'] ?? $napp['first_name'] ?? '';
							$lname = $napp['lname'] ?? $napp['last_name'] ?? '';
							echo h(trim($name . ' ' . $lname)) ?: '—';
							?>&nbsp;</td>
          <td>
              <?php echo !empty($UserPermissions['NappUser']['EoiMailer']) 
                  ? count($UserPermissions['NappUser']['EoiMailer']) 
                  : 0; 
              ?>&nbsp;
          </td>
						<?php $i++; endforeach; ?>
						</tbody>
				</table>			
				</div>
			</div>
		</div>
</div>
</div>
<script>
$(document).ready(function() {
		$('#example').DataTable();
	} );
</script>