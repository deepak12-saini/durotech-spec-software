<?php
/**
 * Flash info message element
 * @var \App\View\AppView $this
 * @var array $params
 * @var string $message
 */
if (!isset($params['escape']) || $params['escape'] !== false) {
    $message = h($message);
}
?>
<div class="message info" onclick="this.classList.add('hidden')"><?= $message ?></div>
