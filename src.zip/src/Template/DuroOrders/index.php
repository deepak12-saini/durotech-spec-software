	<div class="page-content">
		<div class="page-header clearfix">
			<h1 class="pull-left" style="margin-top:0;">Durotech orders List</h1>
			<a href="<?php echo $this->Url->build(['controller' => 'DuroOrders', 'action' => 'add']); ?>" class="btn btn-primary btn-sm pull-right">Add New</a>
		</div>
	
	<div class="row">
		<div class="col-xs-12">
			<div class="table-responsive">
			<table class="table table-striped table-bordered table-hover" id="simple-table" >
				<thead>
				<tr>
					
					<th><?php echo $this->Paginator->sort('customer_order_no'); ?></th>					
					<th><?php echo $this->Paginator->sort('date_of_order'); ?></th>		
					<th><?php echo $this->Paginator->sort('user_id','Added By'); ?></th>					
					<th><?php echo $this->Paginator->sort('account_name'); ?></th>
					<th><?php echo $this->Paginator->sort('order_taken_by'); ?></th>
					<th><?php echo $this->Paginator->sort('contact_name'); ?></th>
					<th><?php echo $this->Paginator->sort('contact_phone'); ?></th>
					<th><?php echo $this->Paginator->sort('deliver_address'); ?></th>
					<th><?php echo $this->Paginator->sort('status'); ?></th>
					<th><?php echo $this->Paginator->sort('created'); ?></th>
					<th>Action</th>
				</tr>
				</thead>
				<tbody>
					<?php
					$k = 1;
					foreach ($DuroOrderArr as $DuroOrderArrs): ?>
					<tr>
						<td><a data-toggle="modal" data-target="#myModal_<?php echo $k; ?>" href="#null"><?php echo h($DuroOrderArrs['DuroOrder']['customer_order_no'] ?? ''); ?></a>&nbsp;</td>						
						<td><?php echo date('d-M-Y',strtotime($DuroOrderArrs['DuroOrder']['date_of_order'] ?? 'now')); ?>&nbsp;</td>		
						<td><?php
						$napp = $DuroOrderArrs['NappUser'] ?? null;
						echo $napp ? h($napp['name'] ?? '') . ' ' . h($napp['lname'] ?? '') : '—';
						?></td>
						<td><?php echo $DuroOrderArrs['DuroOrder']['account_name']; ?>&nbsp;</td>						
						<td><?php echo h($DuroOrderArrs['DuroOrder']['order_taken_by']); ?>&nbsp;</td>
						<td><?php echo h($DuroOrderArrs['DuroOrder']['contact_name']); ?>&nbsp;</td>
						<td><?php echo h($DuroOrderArrs['DuroOrder']['contact_phone']); ?>&nbsp;</td>				
						<td><?php echo h($DuroOrderArrs['DuroOrder']['deliver_address']); ?>&nbsp;</td>				
						<td>
						<?php
							if($DuroOrderArrs['DuroOrder']['status'] == 0){
								echo '<span class="label label-primary">New Order</span>';
							}else if($DuroOrderArrs['DuroOrder']['status'] == 1){
								echo '<span class="label label-danger">Accepted</span>';
							}else if($DuroOrderArrs['DuroOrder']['status'] == 2){
								echo '<span class="label label-success">Delivered</span>';
							}				
		
						?>&nbsp;
						</td>					
						<td> <?php echo date('d-M-Y',strtotime($DuroOrderArrs['DuroOrder']['created'])); ?></td>
						<td>
						<?php if($DuroOrderArrs['DuroOrder']['status'] < 2){ ?>
							<a href="<?php echo $this->Url->build(['controller' => 'DuroOrders', 'action' => 'edit', $DuroOrderArrs['DuroOrder']['id']]); ?>" class="btn btn-sm btn-info">Edit</a>		
						<?php } ?>		
						</td>					
					</tr>
					<?php $k++; endforeach; ?>
				</tbody>
			</table>			
			</div>
		</div>
	</div>		
	<div class="row">
		<div class="col-xs-6">
			<div class="dataTables_info" id="dynamic-table_info" role="status" aria-live="polite"><?php	echo $this->Paginator->counter(array(
'format' => __('showing {{current}} records out of {{count}} entries')));?>	</div>
		</div>
		<div class="col-xs-6">
			<div class="dataTables_paginate paging_simple_numbers" id="dynamic-table_paginate">
			<ul class="pagination">
				<li class="paginate_button previous disabled" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_previous"><?php
				echo $this->Paginator->prev('< ' . __('previous'), array(), null, array('class' => 'prev disabled'));?></li>
				
				<li class="paginate_button next" aria-controls="dynamic-table" tabindex="0" id="dynamic-table_next"><?php echo $this->Paginator->next(__('next') . ' >', array(), null, array('class' => 'next disabled'));?></li>
				
			</ul>
			</div>
		</div>
	</div>	
</div>		

<?php 
	$j=1;
	foreach ($DuroOrderArr as $DuroOrderArrs): 
	
	?>
	<div id="myModal_<?php echo $j; ?>" class="modal fade" role="dialog">
	  <div class="modal-dialog">

		<!-- Modal content-->
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Document Title Records of Library: <?php echo h($DuroOrderArrs['DuroOrder']['customer_order_no']); ?></h4>
		  </div>
		  <div class="modal-body">
			<div class="row">
			<div class="col-xs-12">
				<div class="table-responsive">
				<table class="table table-striped table-bordered table-hover"  >
					<tbody>
					<tr><th>Documentid: </th><td><span class="label label-inverse"><?php echo h($DuroOrderArrs['DuroOrder']['customer_order_no']); ?></span></td></tr>	
					
					<tr><th>Added By: </th><td><?php
					$napp = $DuroOrderArrs['NappUser'] ?? null;
					echo $napp ? h($napp['name'] ?? '') . ' ' . h($napp['lname'] ?? '') : '—';
					?></td></tr>	
					
					<tr><th>Date: </th><td><?php echo date('d-M-Y',strtotime($DuroOrderArrs['DuroOrder']['date_of_order'])); ?></td></tr>	
					<tr><th>Account Name: </th><td><?php echo $DuroOrderArrs['DuroOrder']['account_name']; ?></td></tr>	
					<tr><th>order taken by: </th><td><?php echo $DuroOrderArrs['DuroOrder']['order_taken_by']; ?></td></tr>	
					<tr><th>contact name: </th><td><?php echo $DuroOrderArrs['DuroOrder']['contact_name']; ?></td></tr>	
					<tr><th>contact phone: </th><td><?php echo $DuroOrderArrs['DuroOrder']['contact_phone']; ?></td></tr>						
					<tr><th>deliver address: </th><td><?php echo $DuroOrderArrs['DuroOrder']['deliver_address']; ?></td></tr>						
					<tr><th>Status: </th><td>
					<?php
						if($DuroOrderArrs['DuroOrder']['status'] == 0){
							echo '<span class="label label-primary">New Order</span>';
						}else if($DuroOrderArrs['DuroOrder']['status'] == 1){
							echo '<span class="label label-danger">Accepted</span>';
						}else if($DuroOrderArrs['DuroOrder']['status'] == 2){
							echo '<span class="label label-success">Delivered</span>';
						}				
					?>&nbsp;
						</td></tr>	
					
					<tr><th>Created: </th><td><?php echo date('d-M-Y',strtotime($DuroOrderArrs['DuroOrder']['created'])); ?></td></tr>	
					</tbody>
					
				</table>
				<table class="table table-striped table-bordered table-hover"  >
					<thead>		
						<tr>
							<th>S.no</th>
							<th>Product Name</th>
							<th>size</th>
							<th>color</th>
							<th>qty</th>
						<tr>	
					</thead>
					<tbody>
						<?php 
						$k=1;
						$orderProducts = $DuroOrderArrs['OrderProduct'] ?? [];
						foreach (is_array($orderProducts) ? $orderProducts : [] as $records) {
							$records = is_array($records) ? $records : (array)$records;
						?>
							<tr>
								<th><?php echo $k; ?></th>
								<th><?php echo $records['product_name']; ?></th>
								<th><?php echo $records['size']; ?></th>
								<th><?php echo $records['color']; ?></th>								
								<th><?php echo $records['qty']; ?></th>
								
							<tr>		
						<?php  $k++; } ?>	
					</tbody>
				</table>

				</div>
			</div>
		</div>		
		  </div>
		 
		</div>

	  </div>
	</div>
	<?php $j++; endforeach; ?>
					