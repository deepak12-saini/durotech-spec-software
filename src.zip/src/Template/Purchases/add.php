	<script src="<?php echo SITEURL; ?>ckeditor/ckeditor.js"></script>
	<style>
	fieldset .new {
		background: #ddd;
	}
	</style>
	<div class="page-content">
		<div class="page-header">
		<div class="right_btn pull-right" ><a href="javascript:window.history.back();" class="btn btn-inverse" >Back</a></div>
		<h1>Purchase  <small><i class="ace-icon fa fa-angle-double-right"></i> Add Purchase Request</small>
		</h1>
	</div>
	
	<div class="row">
		<div class="col-xs-12">
		<?php echo $this->Form->create('Purchase',array('class'=>'form-horizontal','enctype'=>'multipart/form-data')); ?>
			
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Date:</label>
				<div class="col-sm-9">
					<?php echo $this->Form->input('date',array('type'=>'text','div'=>false,'label'=>false, 'class' => 'datepicker col-xs-10 col-sm-5','id'=>'date','placeholder'=>'Date','value'=>date('Y-m-d')))?>
				</div>
			</div>	
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Item Detail:</label>
				<div class="col-sm-9">
					<?php echo $this->Form->input('item_details',array('type'=>'text','div'=>false,'label'=>false, 'class' => 'col-xs-10 col-sm-5','id'=>'item_details','placeholder'=>'Item Detail'))?>
				</div>
			</div>	
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Name of the Requisitioner:</label>
				<div class="col-sm-9">
					<?php
					$reqName = $requisitionerName ?? '';
					if ($reqName === '' && method_exists($this->request, 'getSession')) {
						$s = $this->request->getSession();
						$reqName = trim(($s->read('Customer.name') ?? '') . ' ' . ($s->read('Customer.lname') ?? ''));
					}
					echo $this->Form->input('requisitioner_name', array('type' => 'text', 'div' => false, 'label' => false, 'class' => 'col-xs-10 col-sm-5', 'id' => 'requisitioner_name', 'placeholder' => ' Name of the Requisitioner', 'value' => $reqName));
					?>
				</div>
			</div>  
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Permitted By:</label>
				<div class="col-sm-9">
					<select name="data[Purchase][permitted_by]" class="col-xs-10 col-sm-5">
						<option value="">Select Employee</option>
						<?php foreach($employeArr as $employeArrs){ ?>
							<option value="<?php echo $employeArrs['NappUser']['id']; ?>"><?php echo $employeArrs['NappUser']['name'].' '.$employeArrs['NappUser']['lname']; ?></option>
						<?php  }  ?>
					</select>
				</div>
			</div>	
			
			
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="form-field-1"></label>
				<div class="col-sm-9">
				<p><b>Please allow the following Items from the premises of <?php echo SITENAME; ?>:</b></p>
				</div>
			</div>	
			<fieldset class="newitem" >
				<div class="form-group">
					<label class="col-sm-3 control-label no-padding-right " for="form-field-1"></label>
					<div class="col-sm-9"><b>Items 1</b></div>
				</div>			
				<div class="form-group">
					<label class="col-sm-3 control-label no-padding-right new" for="form-field-1">Item Name1</label>
					<div class="col-sm-9">
						<input type="text" name="item_name[]" class="col-xs-10 col-sm-5" required>
					</div>
				</div>	
				<div class="form-group">
					<label class="col-sm-3 control-label no-padding-right new" for="form-field-1">Description Of Items</label>
					<div class="col-sm-9">
						<input type="text" name="description_item[]" class="col-xs-10 col-sm-5" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label no-padding-right new" for="form-field-1">Quantity</label>
					<div class="col-sm-9">
						<select name="quantity[]" class="col-xs-10 col-sm-5 " >
							<?php for($i=1; $i<100; $i++){?>
								<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
							<?php } ?>
						</select>
					</div>
				</div>	
				<div class="form-group">
					<label class="col-sm-3 control-label no-padding-right new" for="form-field-1">Comment</label>
					<div class="col-sm-9">
						<input type="text" name="comments[]" class="col-xs-10 col-sm-5" required>
					</div>
				</div>	
			</fieldset>
			<p id="addmore"></p>
			<div class="form-group">
				<label class="col-sm-3 control-label no-padding-right" for="form-field-1"></label>
				<div class="col-sm-9">
					<a href="#null" class="btn btn-mini btn-danger" onclick="addmore()" >Add More</a>
				</div>
			</div>	
			<div class="form-group">
				<div class="col-md-offset-3 col-md-9">
					<?php echo $this->Form->submit('Submit',array('div'=>false,'label'=>false, 'class' => 'btn btn-mini btn-success','id'=>'add_ser_prd_btn','value'=>'Submit'));?>&nbsp;
					<?php echo $this->Html->link('Cancel','javascript:window.history.back();',array('class' => 'btn btn-mini btn-danger'));?>

				</div>
			</div>
			<?php echo $this->Form->end(); ?>
		</div>
	</div>	
	</div>	
<script type="text/javascript">
	function addmore(){
	
		var numItems = $('.newitem').length;
		
		var newdiv = 	numItems + 1 ;
		
		var newfieldset = '<fieldset class="newitem" id="div_'+newdiv+'"><div class="form-group"><label class="col-sm-3 control-label no-padding-right " for="form-field-1"></label><div class="col-sm-9"><b>Items '+newdiv+' <a href="#null" onclick="remove('+newdiv+')" >&nbsp;&nbsp;&nbsp; Remove</a></b></div></div><div class="form-group"><label class="col-sm-3 control-label no-padding-right new" for="form-field-1">Item Name1</label><div class="col-sm-9"><input type="text" name="item_name[]" class="col-xs-10 col-sm-5" required></div>	</div><div class="form-group"><label class="col-sm-3 control-label no-padding-right new" for="form-field-1">Description Of Items</label><div class="col-sm-9"><input type="text" name="description_item[]" class="col-xs-10 col-sm-5" required>	</div>	</div><div class="form-group">	<label class="col-sm-3 control-label no-padding-right new" for="form-field-1">Quantity</label>	<div class="col-sm-9"><select name="quantity[]" class="col-xs-10 col-sm-5 " ><?php for($i=1; $i<100; $i++){?><option value="<?php echo $i; ?>"><?php echo $i; ?></option><?php } ?></select></div></div><div class="form-group"><label class="col-sm-3 control-label no-padding-right new" for="form-field-1">Comment</label><div class="col-sm-9"><input type="text" name="comments[]" class="col-xs-10 col-sm-5" required></div></div></fieldset>';
		
		$("#addmore").append(newfieldset);
	}
	function remove(id){	
		$("#div_"+id).remove();
	}
	
jQuery(function(){
	$('.ajax-loading-overlay').remove();
	if (typeof jQuery.fn.datepicker !== 'undefined' && $('.datepicker').length) {
		$('.datepicker').datepicker({ format: 'yyyy-mm-dd' });
	}
});
</script>
